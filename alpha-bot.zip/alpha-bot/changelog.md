# v1.0.0
- Initial release: record (practice mode), save .gdr2, search, play.
