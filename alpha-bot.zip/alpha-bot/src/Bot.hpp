#pragma once

#include <Geode/Geode.hpp>
#include <gdr/gdr.hpp>

#include <algorithm>
#include <cctype>
#include <chrono>
#include <filesystem>
#include <fstream>
#include <iterator>
#include <optional>
#include <string>
#include <vector>

using namespace geode::prelude;

namespace alpha {

// ---------------------------------------------------------------- replay type
// Plain GDR2 replay, no custom extensions -> readable by any GDR2-aware bot.
struct AlphaReplay : gdr::Replay<AlphaReplay, gdr::Input<>> {
    AlphaReplay() : Replay("AlphaBot", 1) {}
};

enum class Mode { Idle, Recording, Playing };

struct MacroEntry {
    std::string name;
    std::filesystem::path path;
    std::uintmax_t size = 0;
    std::filesystem::file_time_type time{};
};

// gdr's import/export return a "result" type. Depending on the library revision that
// is geode::Result, std::expected-like, or a plain value, so unwrap all of them here.
template <class R, class T>
bool unwrapInto(R&& r, T& out) {
    if constexpr (requires { r.isOk(); r.unwrap(); }) {
        if (!r.isOk()) return false;
        out = std::move(r.unwrap());
        return true;
    }
    else if constexpr (requires { r.has_value(); r.value(); }) {
        if (!r.has_value()) return false;
        out = std::move(r.value());
        return true;
    }
    else {
        out = std::move(r);
        return true;
    }
}

inline constexpr char const* kNameChars =
    "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 _-.";

inline std::string sanitizeName(std::string const& s) {
    std::string o;
    for (unsigned char c : s) {
        if (std::isalnum(c) || c == ' ' || c == '_' || c == '-' || c == '.') o.push_back(char(c));
    }
    while (!o.empty() && (o.back() == ' ' || o.back() == '.')) o.pop_back();
    size_t st = 0;
    while (st < o.size() && (o[st] == ' ' || o[st] == '.')) ++st;
    o.erase(0, st);
    if (o.size() > 40) o.resize(40);
    if (o.empty()) o = "macro";
    return o;
}

inline std::string lower(std::string s) {
    for (auto& c : s) c = char(std::tolower(static_cast<unsigned char>(c)));
    return s;
}

// GJGameLevel::m_levelID is a seed-protected value in recent bindings (.value()),
// a plain int in older ones. Support both.
template <class L>
uint32_t levelIdOf(L* level) {
    if constexpr (requires { level->m_levelID.value(); }) return static_cast<uint32_t>(level->m_levelID.value());
    else return static_cast<uint32_t>(level->m_levelID);
}

inline std::filesystem::path macroDir() {
    auto p = Mod::get()->getSaveDir() / "macros";
    std::error_code ec;
    std::filesystem::create_directories(p, ec);
    return p;
}

// ------------------------------------------------------------------------ bot
class Bot {
public:
    static Bot& get() {
        static Bot instance;
        return instance;
    }

    static constexpr double kTps = 240.0;

    Mode mode = Mode::Idle;
    AlphaReplay replay;               // recording buffer / loaded macro
    std::string recName = "my macro";
    std::string status = "Ready.";
    std::vector<MacroEntry> macros;

    // runtime state
    uint64_t cmdFrame = 0;            // frame at entry of the current processCommands
    bool inCommands = false;
    bool injecting = false;
    bool pendingSync = false;
    size_t playIdx = 0;

    // ------------------------------------------------------------ helpers
    uint64_t frameNow(GJBaseGameLayer* gl) const {
        // Using the frame captured at processCommands entry keeps recording and
        // playback perfectly symmetric, whatever order the game increments things in.
        return inCommands ? cmdFrame : static_cast<uint64_t>(gl->m_gameState.m_currentProgress);
    }

    bool heldAt(bool p2, size_t upto) const {
        bool d = false;
        auto const& in = replay.inputs;
        for (size_t i = 0; i < upto && i < in.size(); ++i) {
            if (in[i].player2 == p2) d = in[i].down;
        }
        return d;
    }

    static bool actuallyHeld(PlayLayer* pl, bool p2) {
        auto* p = p2 ? pl->m_player2 : pl->m_player1;
        return p && p->m_holdingButton;
    }

    void sortInputs() {
        std::stable_sort(replay.inputs.begin(), replay.inputs.end(),
            [](auto const& a, auto const& b) { return a.frame < b.frame; });
    }

    // ------------------------------------------------------------ library
    void refresh() {
        macros.clear();
        std::error_code ec;
        for (auto const& e : std::filesystem::directory_iterator(macroDir(), ec)) {
            std::error_code ec2;
            if (!e.is_regular_file(ec2)) continue;
            if (e.path().extension() != ".gdr2") continue;
            MacroEntry m;
            m.name = e.path().stem().string();
            m.path = e.path();
            m.size = e.file_size(ec2);
            m.time = e.last_write_time(ec2);
            macros.push_back(std::move(m));
        }
        std::sort(macros.begin(), macros.end(),
            [](auto const& a, auto const& b) { return a.time > b.time; });
    }

    // ---------------------------------------------------------- recording
    bool startRecord(PlayLayer* pl) {
        if (!pl) { status = "Open a level first."; return false; }
        if (!pl->m_isPracticeMode) { status = "Recording works in Practice mode only."; return false; }
        if (pl->m_levelSettings && pl->m_levelSettings->m_platformerMode) {
            status = "Platformer levels are not supported yet.";
            return false;
        }

        replay = AlphaReplay();
        replay.author = std::string(GameManager::get()->m_playerName.c_str());
        replay.gameVersion = GEODE_COMP_GD_VERSION;
        replay.framerate = kTps;
        replay.platformer = false;
        replay.levelInfo.id = levelIdOf(pl->m_level);
        replay.levelInfo.name = std::string(pl->m_level->m_levelName.c_str());

        mode = Mode::Recording;
        pendingSync = false;
        status = "Recording... play the level from the start.";
        return true;
    }

    void onButton(PlayLayer* pl, bool down, int button, bool isPlayer1) {
        if (mode != Mode::Recording || button != 1) return;
        replay.inputs.emplace_back(frameNow(pl), uint8_t(1), !isPlayer1, down);
    }

    void cancelRecord(std::string const& why) {
        mode = Mode::Idle;
        replay.inputs.clear();
        status = why;
    }

    // Stops recording and writes <name>.gdr2. Returns true on success.
    bool finishRecord(PlayLayer* pl) {
        if (mode != Mode::Recording) return false;
        mode = Mode::Idle;

        if (replay.inputs.empty()) {
            status = "Nothing recorded (no inputs).";
            return false;
        }
        sortInputs();

        uint64_t end = replay.inputs.back().frame + 1;
        if (pl) end = std::max<uint64_t>(end, static_cast<uint64_t>(pl->m_gameState.m_currentProgress));
        replay.duration = static_cast<float>(double(end) / kTps);

        auto res = replay.exportData();
        std::vector<uint8_t> bytes;
        if (!unwrapInto(res, bytes) || bytes.empty()) {
            status = "Failed to encode the macro.";
            return false;
        }

        auto dir = macroDir();
        std::string base = sanitizeName(recName);
        auto path = dir / (base + ".gdr2");
        for (int i = 2; std::filesystem::exists(path); ++i) {
            path = dir / (base + "_" + std::to_string(i) + ".gdr2");
        }

        std::ofstream f(path, std::ios::binary);
        if (!f) {
            status = "Could not write the file.";
            return false;
        }
        f.write(reinterpret_cast<char const*>(bytes.data()), std::streamsize(bytes.size()));
        f.close();

        status = fmt::format("Saved {} ({} inputs).", path.filename().string(), replay.inputs.size());
        refresh();
        return true;
    }

    // ---------------------------------------------------------- playback
    bool loadMacro(MacroEntry const& e) {
        std::ifstream f(e.path, std::ios::binary);
        if (!f) { status = "Cannot open the file."; return false; }
        std::vector<uint8_t> data((std::istreambuf_iterator<char>(f)), std::istreambuf_iterator<char>());

        auto res = AlphaReplay::importData(data);
        AlphaReplay loaded;
        if (!unwrapInto(res, loaded)) { status = "Invalid or unsupported .gdr2 file."; return false; }
        if (loaded.platformer) { status = "Platformer macros are not supported yet."; return false; }
        if (loaded.inputs.empty()) { status = "This macro has no inputs."; return false; }

        replay = std::move(loaded);
        sortInputs();
        return true;
    }

    bool startPlay(PlayLayer* pl, MacroEntry const& e) {
        if (!pl) { status = "Open a level first."; return false; }
        if (!loadMacro(e)) return false;

        mode = Mode::Playing;
        playIdx = 0;
        pendingSync = false;

        auto id = levelIdOf(pl->m_level);
        if (replay.levelInfo.id != 0 && replay.levelInfo.id != id) {
            status = "Playing (note: this macro was recorded on another level).";
        } else {
            status = fmt::format("Playing {}", e.name);
        }
        return true;
    }

    void stopPlay(PlayLayer* pl) {
        if (mode != Mode::Playing) return;
        mode = Mode::Idle;
        if (pl) releaseAll(pl);
        status = "Stopped.";
    }

    void inject(GJBaseGameLayer* gl, bool down, bool p2) {
        injecting = true;
        gl->handleButton(down, 1, !p2);
        injecting = false;
    }

    void releaseAll(PlayLayer* pl) {
        for (bool p2 : {false, true}) {
            if (actuallyHeld(pl, p2)) inject(pl, false, p2);
        }
    }

    // Called at the start of every physics step while playing.
    void tickPlayback(PlayLayer* pl) {
        auto const& in = replay.inputs;
        if (pendingSync) {
            pendingSync = false;
            for (bool p2 : {false, true}) {
                bool want = heldAt(p2, playIdx);
                if (want != actuallyHeld(pl, p2)) inject(pl, want, p2);
            }
        }
        while (playIdx < in.size() && in[playIdx].frame <= cmdFrame) {
            auto const& i = in[playIdx++];
            inject(pl, i.down, i.player2);
        }
    }

    // ----------------------------------------------------- level lifecycle
    // Called right after PlayLayer::resetLevel (start, death, practice respawn).
    void onReset(PlayLayer* pl) {
        uint64_t f = static_cast<uint64_t>(pl->m_gameState.m_currentProgress);

        if (mode == Mode::Recording) {
            // Dropped attempt: forget everything from this frame on.
            auto& in = replay.inputs;
            std::erase_if(in, [f](auto const& i) { return i.frame >= f; });
            // Keep the macro's hold state consistent with the restored player state.
            for (bool p2 : {false, true}) {
                bool want = heldAt(p2, in.size());
                bool have = actuallyHeld(pl, p2);
                if (want != have) in.emplace_back(f, uint8_t(1), p2, have);
            }
        }
        else if (mode == Mode::Playing) {
            auto const& in = replay.inputs;
            playIdx = size_t(std::lower_bound(in.begin(), in.end(), f,
                [](auto const& i, uint64_t fr) { return i.frame < fr; }) - in.begin());
            pendingSync = true;
        }
    }

    void onLevelComplete(PlayLayer* pl) {
        if (mode == Mode::Recording) finishRecord(pl);
        else if (mode == Mode::Playing) { mode = Mode::Idle; status = "Macro finished."; }
    }

    void onQuit(PlayLayer* pl) {
        if (mode == Mode::Recording) {
            // Do not lose a long recording because of an accidental exit.
            if (!replay.inputs.empty()) finishRecord(pl);
            else mode = Mode::Idle;
        }
        else if (mode == Mode::Playing) {
            mode = Mode::Idle;
        }
    }
};

} // namespace alpha
