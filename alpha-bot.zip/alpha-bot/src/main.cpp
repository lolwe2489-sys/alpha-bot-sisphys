#include <Geode/Geode.hpp>
#include <Geode/modify/GJBaseGameLayer.hpp>
#include <Geode/modify/PlayLayer.hpp>
#include <Geode/modify/PauseLayer.hpp>

#include "Bot.hpp"
#include "Ui.hpp"

using namespace geode::prelude;
using alpha::Bot;
using alpha::Mode;

// ---------------------------------------------------------------- ImGui setup
$on_mod(Loaded) {
    ImGuiCocos::get().setup([] {
        alpha::ui::applyStyle();
    }).draw([] {
        alpha::ui::draw();
    });
    Bot::get().refresh();
}

// ------------------------------------------------- input recording / playback
class $modify(AlphaGameLayer, GJBaseGameLayer) {
    // Runs once per physics step (240/s). Playback injects the recorded inputs here,
    // *before* the original function, so they land in exactly the step they were recorded in.
    void processCommands(float dt, bool isHalfTick, bool isLastTick) {
        auto& bot = Bot::get();
        auto* pl = PlayLayer::get();

        if (pl && static_cast<GJBaseGameLayer*>(pl) == this && bot.mode != Mode::Idle) {
            if (bot.mode == Mode::Recording && !pl->m_isPracticeMode) {
                bot.cancelRecord("Practice mode was turned off - recording cancelled.");
            }
            else {
                bot.cmdFrame = static_cast<uint64_t>(m_gameState.m_currentProgress);
                if (bot.mode == Mode::Playing && !isHalfTick) bot.tickPlayback(pl);

                bot.inCommands = true;
                GJBaseGameLayer::processCommands(dt, isHalfTick, isLastTick);
                bot.inCommands = false;
                return;
            }
        }
        GJBaseGameLayer::processCommands(dt, isHalfTick, isLastTick);
    }

    // Every press / release that reaches the game passes through here.
    void handleButton(bool down, int button, bool isPlayer1) {
        auto& bot = Bot::get();
        auto* pl = PlayLayer::get();

        if (pl && static_cast<GJBaseGameLayer*>(pl) == this) {
            // while a macro plays, the player's own taps are ignored
            if (bot.mode == Mode::Playing && !bot.injecting) return;
            if (bot.mode == Mode::Recording) bot.onButton(pl, down, button, isPlayer1);
        }
        GJBaseGameLayer::handleButton(down, button, isPlayer1);
    }
};

class $modify(AlphaPlayLayer, PlayLayer) {
    void resetLevel() {
        PlayLayer::resetLevel();
        Bot::get().onReset(this);
    }

    void levelComplete() {
        PlayLayer::levelComplete();
        Bot::get().onLevelComplete(this);
    }

    void onQuit() {
        Bot::get().onQuit(this);
        PlayLayer::onQuit();
    }
};

// ------------------------------------------------------------ pause-menu icon
class $modify(AlphaPauseLayer, PauseLayer) {
    void customSetup() {
        PauseLayer::customSetup();

        auto win = CCDirector::get()->getWinSize();

        auto spr = CCSprite::create("alpha-icon.png"_spr);
        if (!spr) return;
        spr->setScale(38.f / spr->getContentSize().width);

        auto btn = CCMenuItemSpriteExtra::create(spr, this, menu_selector(AlphaPauseLayer::onAlphaBot));
        btn->setPosition({win.width - 34.f, win.height * 0.30f});   // right edge of the pause screen

        auto menu = CCMenu::create();
        menu->setPosition({0.f, 0.f});
        menu->setID("alpha-bot-menu"_spr);
        menu->addChild(btn);
        this->addChild(menu, 10);

        // closes the ImGui window together with the pause menu
        if (auto w = alpha::ui::ExitWatcher::create()) this->addChild(w);
    }

    void onAlphaBot(CCObject*) {
        alpha::ui::open(this);
    }
};
