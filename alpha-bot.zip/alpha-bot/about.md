# Alpha Bot

Small and precise macro bot.

- Open the pause menu and tap the **α** icon.
- Record in **Practice mode** (the level restarts from the beginning, checkpoints are respected).
- Macros are saved as **.gdr2** and can be replayed from the same menu.
- Use the search field to find macros by name.
