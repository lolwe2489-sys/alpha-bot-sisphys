# Alpha Bot (Geode, GD 2.2081, Geode v5)

Tiny macro bot: record in Practice mode -> save `.gdr2` -> search -> play.

## Build on your phone (no PC): GitHub Actions
1. Create a GitHub repo, upload ALL files of this folder (keep the `.github/workflows/build.yml` path).
2. In `mod.json` change `"id"` and `"developer"` (id must look like `yourname.alpha-bot`).
3. Repo -> Actions -> "Build Alpha Bot" -> Run workflow (it also runs on every push).
4. When it is green, open the run -> Artifacts -> "Alpha Bot (.geode)". Unzip it.
5. Copy `*.geode` to `/storage/emulated/0/Android/media/com.geode.launcher/game/geode/mods/` and restart GD.

## Build on a PC
```
geode sdk install
geode sdk install-binaries -p android64     # android32 for 32-bit phones
geode build -p android64
```
(needs the Android NDK, see https://docs.geode-sdk.org/getting-started/create-mod)

## Files
- `src/Bot.hpp`  recording / playback / GDR2 I/O
- `src/Ui.hpp`   Dear ImGui menu + native text popup
- `src/main.cpp` hooks + pause-menu icon
- `resources/alpha-icon.svg` source of the icon (PNG sizes are generated from it)
