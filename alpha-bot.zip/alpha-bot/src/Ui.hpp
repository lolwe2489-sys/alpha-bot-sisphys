#pragma once

#include "Bot.hpp"

#include <imgui-cocos.hpp>
#include <Geode/ui/Popup.hpp>
#include <Geode/ui/TextInput.hpp>

#include <cfloat>
#include <functional>

namespace alpha::ui {

inline bool g_open = false;      // menu requested by the pause-menu icon
inline bool g_hidden = false;    // temporarily hidden (a native popup is on screen)
inline float g_scale = 1.f;
inline std::string g_search;
inline std::filesystem::path g_selected;
inline PauseLayer* g_pause = nullptr;   // set while our pause-menu icon exists (cleared by ExitWatcher)

// Close the pause menu and restart the level from frame 0 (record / playback both start there).
inline void resumeAndRestart() {
    queueInMainThread([] {
        auto* pl = PlayLayer::get();
        if (!pl) return;
        if (g_pause) {
            auto* p = g_pause;
            g_pause = nullptr;
            p->onResume(nullptr);
        }
        pl->resetLevelFromStart();
    });
}

// ------------------------------------------------------------ native text input
// ImGui text fields need an on-screen keyboard, which is unreliable on phones.
// GD's own TextInput works everywhere, so ImGui just opens it. While the popup is up
// the ImGui window is hidden (ImGui is drawn on top of every cocos node).
class TextPopup : public Popup {
protected:
    TextInput* m_input = nullptr;
    std::function<void(std::string const&)> m_done;

    bool init(std::string const& title, std::string const& initial, std::string const& placeholder,
              size_t maxLen, std::function<void(std::string const&)> done) {
        if (!Popup::init(300.f, 150.f)) return false;
        g_hidden = true;
        m_done = std::move(done);

        this->setTitle(title);

        m_input = TextInput::create(230.f, placeholder);
        m_input->setFilter(kNameChars);
        m_input->setMaxCharCount(maxLen);
        m_input->setString(initial);
        m_mainLayer->addChildAtPosition(m_input, Anchor::Center, ccp(0.f, 8.f));

        auto ok = CCMenuItemSpriteExtra::create(
            ButtonSprite::create("OK"), this, menu_selector(TextPopup::onOk));
        m_buttonMenu->addChildAtPosition(ok, Anchor::Bottom, ccp(0.f, 28.f));
        return true;
    }

    void onOk(CCObject*) {
        if (m_done) m_done(m_input->getString());
        this->onClose(nullptr);
    }

public:
    static TextPopup* create(std::string const& title, std::string const& initial,
                             std::string const& placeholder, size_t maxLen,
                             std::function<void(std::string const&)> done) {
        auto ret = new TextPopup();
        if (ret->init(title, initial, placeholder, maxLen, std::move(done))) {
            ret->autorelease();
            return ret;
        }
        delete ret;
        return nullptr;
    }

    ~TextPopup() override { g_hidden = false; }
};

inline void askName() {
    queueInMainThread([] {
        auto p = TextPopup::create("Macro name", Bot::get().recName, "macro name", 40,
            [](std::string const& s) { Bot::get().recName = sanitizeName(s); });
        if (p) p->show();
    });
}

inline void askSearch() {
    queueInMainThread([] {
        auto p = TextPopup::create("Search macros", g_search, "type a name", 40,
            [](std::string const& s) { g_search = s; });
        if (p) p->show();
    });
}

// ---------------------------------------------------------------------- style
inline void applyStyle() {
    auto* view = CCDirector::get()->getOpenGLView();
    float h = view ? view->getFrameSize().height : 720.f;
    g_scale = std::clamp(h / 540.f, 1.f, 3.5f);
    float s = g_scale;

    ImGuiIO& io = ImGui::GetIO();
    io.IniFilename = nullptr;

    ImFontConfig cfg;
    cfg.SizePixels = 15.f * s;
    io.FontDefault = io.Fonts->AddFontDefault(&cfg);

    ImGuiStyle& st = ImGui::GetStyle();
    st = ImGuiStyle();
    st.WindowRounding = 18.f * s;
    st.ChildRounding = 14.f * s;
    st.FrameRounding = 11.f * s;
    st.PopupRounding = 11.f * s;
    st.ScrollbarRounding = 12.f * s;
    st.WindowBorderSize = 2.f * s;
    st.ChildBorderSize = 1.f * s;
    st.FrameBorderSize = 0.f;
    st.WindowPadding = ImVec2(18.f * s, 16.f * s);
    st.FramePadding = ImVec2(14.f * s, 10.f * s);
    st.ItemSpacing = ImVec2(12.f * s, 10.f * s);
    st.ItemInnerSpacing = ImVec2(8.f * s, 6.f * s);
    st.ScrollbarSize = 26.f * s;
    st.ButtonTextAlign = ImVec2(0.5f, 0.5f);

    auto* c = st.Colors;
    c[ImGuiCol_Text]             = ImVec4(0.96f, 0.96f, 0.97f, 1.f);
    c[ImGuiCol_TextDisabled]     = ImVec4(0.55f, 0.55f, 0.60f, 1.f);
    c[ImGuiCol_WindowBg]         = ImVec4(0.035f, 0.035f, 0.045f, 0.97f);
    c[ImGuiCol_ChildBg]          = ImVec4(0.075f, 0.075f, 0.095f, 1.f);
    c[ImGuiCol_Border]           = ImVec4(1.f, 1.f, 1.f, 0.85f);
    c[ImGuiCol_FrameBg]          = ImVec4(0.11f, 0.11f, 0.14f, 1.f);
    c[ImGuiCol_Button]           = ImVec4(0.14f, 0.14f, 0.18f, 1.f);
    c[ImGuiCol_ButtonHovered]    = ImVec4(0.21f, 0.21f, 0.27f, 1.f);
    c[ImGuiCol_ButtonActive]     = ImVec4(0.32f, 0.32f, 0.40f, 1.f);
    c[ImGuiCol_Header]           = ImVec4(0.24f, 0.24f, 0.32f, 1.f);
    c[ImGuiCol_HeaderHovered]    = ImVec4(0.28f, 0.28f, 0.36f, 1.f);
    c[ImGuiCol_HeaderActive]     = ImVec4(0.34f, 0.34f, 0.44f, 1.f);
    c[ImGuiCol_Separator]        = ImVec4(1.f, 1.f, 1.f, 0.14f);
    c[ImGuiCol_ScrollbarBg]      = ImVec4(0.f, 0.f, 0.f, 0.f);
    c[ImGuiCol_ScrollbarGrab]    = ImVec4(0.42f, 0.42f, 0.50f, 1.f);
    c[ImGuiCol_ScrollbarGrabHovered] = ImVec4(0.55f, 0.55f, 0.64f, 1.f);
    c[ImGuiCol_ScrollbarGrabActive]  = ImVec4(0.70f, 0.70f, 0.80f, 1.f);
}

// -------------------------------------------------------------------- widgets
inline bool accentButton(char const* label, ImVec2 size, ImVec4 c) {
    ImGui::PushStyleColor(ImGuiCol_Button, c);
    ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(c.x * 1.12f, c.y * 1.12f, c.z * 1.12f, 1.f));
    ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(c.x * 0.78f, c.y * 0.78f, c.z * 0.78f, 1.f));
    bool r = ImGui::Button(label, size);
    ImGui::PopStyleColor(3);
    return r;
}

inline std::string sizeText(std::uintmax_t b) {
    if (b < 1024) return fmt::format("{} B", b);
    return fmt::format("{:.1f} KB", double(b) / 1024.0);
}

inline const ImVec4 kRed   = ImVec4(0.78f, 0.17f, 0.24f, 1.f);
inline const ImVec4 kGreen = ImVec4(0.13f, 0.55f, 0.34f, 1.f);

// ----------------------------------------------------------------------- menu
inline void draw() {
    if (!g_open || g_hidden) return;

    auto& bot = Bot::get();
    auto* pl = PlayLayer::get();
    ImGuiIO& io = ImGui::GetIO();
    float s = g_scale;

    ImVec2 disp = io.DisplaySize;
    ImGui::SetNextWindowSize(
        ImVec2(std::min(disp.x * 0.68f, 980.f * s), std::min(disp.y * 0.88f, 600.f * s)),
        ImGuiCond_Always);
    ImGui::SetNextWindowPos(ImVec2(disp.x * 0.5f, disp.y * 0.5f), ImGuiCond_Always, ImVec2(0.5f, 0.5f));

    ImGuiWindowFlags wf = ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize |
        ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoSavedSettings |
        ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse;

    if (!ImGui::Begin("##AlphaBot", nullptr, wf)) {
        ImGui::End();
        return;
    }

    float fh = ImGui::GetFrameHeight();
    float bh = fh * 1.25f;

    // ---- header
    {
        char const* title = "Alpha Bot";
        float tsz = ImGui::GetFontSize() * 1.7f;
        ImVec2 p = ImGui::GetCursorScreenPos();
        ImGui::GetWindowDrawList()->AddText(ImGui::GetFont(), tsz, p, IM_COL32(255, 255, 255, 255), title);
        ImGui::Dummy(ImVec2(ImGui::CalcTextSize(title).x * 1.7f + 8.f * s, tsz));

        ImGui::SameLine();
        char const* st = "IDLE";
        ImVec4 sc = ImVec4(0.6f, 0.6f, 0.66f, 1.f);
        if (bot.mode == Mode::Recording) { st = "REC"; sc = ImVec4(1.f, 0.35f, 0.40f, 1.f); }
        if (bot.mode == Mode::Playing)   { st = "PLAY"; sc = ImVec4(0.40f, 0.95f, 0.60f, 1.f); }
        ImGui::AlignTextToFramePadding();
        ImGui::TextColored(sc, "[ %s ]", st);

        float closeW = fh * 3.2f;
        ImGui::SameLine(ImGui::GetWindowWidth() - closeW - ImGui::GetStyle().WindowPadding.x);
        if (ImGui::Button("Close", ImVec2(closeW, fh))) g_open = false;
    }
    ImGui::Separator();

    // ---- panes
    float availW = ImGui::GetContentRegionAvail().x;
    float footerH = ImGui::GetTextLineHeightWithSpacing() * 1.6f;
    float availH = ImGui::GetContentRegionAvail().y - footerH;
    float gap = ImGui::GetStyle().ItemSpacing.x;
    float leftW = (availW - gap) * 0.42f;

    // ===== left: recording
    ImGui::BeginChild("##rec", ImVec2(leftW, availH), true);
    {
        ImGui::TextDisabled("NEW MACRO");
        ImGui::TextUnformatted("Name");
        std::string nameLabel = bot.recName + "  (tap to edit)";
        if (ImGui::Button(nameLabel.c_str(), ImVec2(-FLT_MIN, bh))) askName();

        ImGui::Spacing();
        bool practice = pl && pl->m_isPracticeMode;

        if (bot.mode == Mode::Recording) {
            if (accentButton("Stop & save", ImVec2(-FLT_MIN, bh), kRed)) {
                bot.finishRecord(pl);
            }
            ImGui::TextColored(ImVec4(1.f, 0.40f, 0.45f, 1.f), "Inputs: %d", int(bot.replay.inputs.size()));
        }
        else {
            ImGui::BeginDisabled(!practice || bot.mode == Mode::Playing);
            if (accentButton("Record from start", ImVec2(-FLT_MIN, bh), kRed)) {
                if (bot.startRecord(pl)) {
                    g_open = false;
                    resumeAndRestart();
                }
            }
            ImGui::EndDisabled();
            if (!practice) ImGui::TextColored(ImVec4(1.f, 0.75f, 0.30f, 1.f), "Turn on Practice mode first.");
        }

        ImGui::Spacing();
        ImGui::PushStyleColor(ImGuiCol_Text, ImGui::GetStyle().Colors[ImGuiCol_TextDisabled]);
        ImGui::TextWrapped("The level restarts from the beginning. Checkpoints work: after a respawn the dropped part of the run is discarded. The macro is saved automatically when you finish the level or leave it.");
        ImGui::PopStyleColor();
    }
    ImGui::EndChild();

    ImGui::SameLine();

    // ===== right: library
    ImGui::BeginChild("##lib", ImVec2(0, availH), true);
    {
        ImGui::TextDisabled("MACROS");
        ImGui::SameLine(ImGui::GetWindowWidth() - fh * 4.2f - ImGui::GetStyle().WindowPadding.x);
        if (ImGui::SmallButton("Refresh")) bot.refresh();

        std::string searchLabel = g_search.empty() ? std::string("Search macros...") : ("Search: " + g_search);
        float clearW = g_search.empty() ? 0.f : (fh + gap);
        if (ImGui::Button(searchLabel.c_str(), ImVec2(ImGui::GetContentRegionAvail().x - clearW, bh))) askSearch();
        if (!g_search.empty()) {
            ImGui::SameLine();
            if (ImGui::Button("X", ImVec2(fh, bh))) g_search.clear();
        }

        float listH = ImGui::GetContentRegionAvail().y - bh - ImGui::GetStyle().ItemSpacing.y;
        ImGui::PushStyleColor(ImGuiCol_ChildBg, ImVec4(0.04f, 0.04f, 0.055f, 1.f));
        ImGui::BeginChild("##list", ImVec2(0, listH), true);
        {
            std::string q = lower(g_search);
            int shown = 0;
            ImDrawList* dl = ImGui::GetWindowDrawList();
            for (auto const& m : bot.macros) {
                if (!q.empty() && lower(m.name).find(q) == std::string::npos) continue;
                ++shown;
                ImGui::PushID(shown);
                bool sel = (m.path == g_selected);
                if (ImGui::Selectable(m.name.c_str(), sel, 0, ImVec2(0, fh * 1.1f))) {
                    // ignore taps that were really a scroll-drag
                    if (io.MouseDragMaxDistanceSqr[0] < (10.f * s) * (10.f * s)) g_selected = m.path;
                }
                std::string sz = sizeText(m.size);
                ImVec2 mn = ImGui::GetItemRectMin(), mx = ImGui::GetItemRectMax();
                ImVec2 ts = ImGui::CalcTextSize(sz.c_str());
                dl->AddText(ImVec2(mx.x - ts.x - 10.f * s, mn.y + (mx.y - mn.y - ts.y) * 0.5f),
                            IM_COL32(140, 140, 155, 255), sz.c_str());
                ImGui::PopID();
            }
            if (shown == 0) {
                ImGui::TextDisabled("%s", bot.macros.empty() ? "No macros yet. Record one!" : "No macros found.");
            }
            // finger-drag scrolling
            if (ImGui::IsWindowHovered() && ImGui::IsMouseDragging(0, 12.f * s)) {
                ImGui::SetScrollY(ImGui::GetScrollY() - io.MouseDelta.y);
            }
        }
        ImGui::EndChild();
        ImGui::PopStyleColor();

        if (bot.mode == Mode::Playing) {
            if (accentButton("Stop", ImVec2(-FLT_MIN, bh), kRed)) bot.stopPlay(pl);
        }
        else {
            auto it = std::find_if(bot.macros.begin(), bot.macros.end(),
                [](auto const& m) { return m.path == g_selected; });
            bool ok = it != bot.macros.end() && pl && bot.mode != Mode::Recording;
            ImGui::BeginDisabled(!ok);
            if (accentButton("Play", ImVec2(-FLT_MIN, bh), kGreen)) {
                if (bot.startPlay(pl, *it)) {
                    g_open = false;
                    resumeAndRestart();
                }
            }
            ImGui::EndDisabled();
        }
    }
    ImGui::EndChild();

    // ---- footer
    ImGui::TextDisabled("%s", bot.status.c_str());

    ImGui::End();
}

inline void open(PauseLayer* pause) {
    g_pause = pause;
    Bot::get().refresh();
    g_open = true;
}

// Child node of the PauseLayer: when the pause menu goes away (resume / restart / quit)
// the ImGui window closes with it, without needing any extra hook.
class ExitWatcher : public CCNode {
public:
    static ExitWatcher* create() {
        auto ret = new ExitWatcher();
        if (ret->init()) {
            ret->autorelease();
            return ret;
        }
        delete ret;
        return nullptr;
    }
    void onExit() override {
        CCNode::onExit();
        g_open = false;
        g_pause = nullptr;
    }
};

} // namespace alpha::ui
